# Testing Playwright with TS on LambdaTest

## Setup
* Clone the repo. Run `cd playwright-test-ts`
* Install dependencies. Run `npm install`

## Running your tests
- To run a single test, run 
  ```npm run test```
